----------------------------------------------------
---------- Html Agility Pack Nuget Readme ----------
----------------------------------------------------

----Silverlight 4 and Windows Phone 7.1+ projects-----
To use XPATH features: System.Xml.Xpath.dll from the Silverlight 4 SDK must be referenced. 
This is normally found at 
%ProgramFiles(x86)%\Microsoft SDKs\Microsoft SDKs\Silverlight\v4.0\Libraries\Client 
or 
%ProgramFiles%\Microsoft SDKs\Microsoft SDKs\Silverlight\v4.0\Libraries\Client

----Silverlight 5 projects-----
To use XPATH features: System.Xml.Xpath.dll from the Silverlight 5 SDK must be referenced. 
This is normally found at 
%ProgramFiles(x86)%\Microsoft SDKs\Microsoft SDKs\Silverlight\v5.0\Libraries\Client 
or 
%ProgramFiles%\Microsoft SDKs\Microsoft SDKs\Silverlight\v5.0\Libraries\Client
